<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_FrequentlyBought
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\FrequentlyBought\Controller\Wishlist;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\DataObject;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NotFoundException;
use Magento\Wishlist\Controller\WishlistProviderInterface;
use Magento\Wishlist\Helper\Data;
use Mageplaza\FrequentlyBought\Helper\Data as FbtData;

/**
 * Class Add
 * @package Mageplaza\FrequentlyBought\Controller\Wishlist
 */
class Add extends \Magento\Wishlist\Controller\Index\Add
{
    /**
     * @var \Mageplaza\FrequentlyBought\Helper\Data
     */
    private $fbtDataHelper;

    /**
     * @var \Magento\Wishlist\Helper\Data
     */
    private $wishlistDataHelper;

    /**
     * Constructor
     *
     * @param Action\Context $context
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Wishlist\Controller\WishlistProviderInterface $wishlistProvider
     * @param ProductRepositoryInterface $productRepository
     * @param Validator $formKeyValidator
     * @param \Magento\Wishlist\Helper\Data $wishlistDataHelper
     * @param \Mageplaza\FrequentlyBought\Helper\Data $fbtDataHelper
     */
    public function __construct(
        Action\Context $context,
        Session $customerSession,
        WishlistProviderInterface $wishlistProvider,
        ProductRepositoryInterface $productRepository,
        Validator $formKeyValidator,
        Data $wishlistDataHelper,
        FbtData $fbtDataHelper
    )
    {
        $this->wishlistDataHelper = $wishlistDataHelper;
        $this->fbtDataHelper      = $fbtDataHelper;

        parent::__construct(
            $context,
            $customerSession,
            $wishlistProvider,
            $productRepository,
            $formKeyValidator
        );
    }

    /**
     * Adding new item
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     * @throws NotFoundException
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.UnusedLocalVariable)
     */
    public function execute()
    {
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        if (!$this->fbtDataHelper->isEnabled()) {
            return $resultRedirect->setPath('*/*/');
        }
        $wishlist = $this->wishlistProvider->getWishlist();
        if (!$wishlist) {
            throw new NotFoundException(__('Page not found.'));
        }
        $params = $this->getRequest()->getParams();
        if ($this->_customerSession->getBeforeWishlistRequest()) {
            $params = $this->_customerSession->getBeforeWishlistRequest();
            $this->_customerSession->unsBeforeWishlistRequest();
        }
        try {
            if (!empty($params['mageplaza_fbt'])) {
                $productsName = [];
                foreach ($params['mageplaza_fbt'] as $productId => $value) {
                    $requestParams = [];
                    $product       = $this->productRepository->getById($productId);
                    if (!$product || !$product->isVisibleInCatalog()) {
                        $this->messageManager->addErrorMessage(__('We can\'t specify a product.'));
                        $resultRedirect->setPath('*/');

                        return $resultRedirect;
                    }
                    $productType              = $product->getTypeId();
                    $requestParams['product'] = $productId;
                    switch ($productType) {
                        case 'configurable' :
                            if (isset($params['super_attribute']) && isset($params['super_attribute'][$productId])) {
                                $requestParams['super_attribute'] = $params['super_attribute'][$productId];
                            }
                            break;
                        case 'grouped':
                            if (isset($params['super_group']) && isset($params['super_group'][$productId])) {
                                $requestParams['super_group'] = $params['super_group'][$productId];
                            }
                            break;
                        case 'bundle':
                            if (isset($params['bundle_option']) && isset($params['bundle_option'][$productId])) {
                                $requestParams['bundle_option']     = $params['bundle_option'][$productId];
                                $requestParams['bundle_option_qty'] = $params['bundle_option_qty'][$productId];
                            }
                            break;
                        case 'downloadable':
                            if (isset($params['links']) && isset($params['links'][$productId])) {
                                $requestParams['links'] = $params['links'][$productId];
                            }
                            break;
                        default:
                            break;
                    }
                    if (isset($params['options_' . $productId])) {
                        $requestParams['options'] = $params['options_' . $productId];
                    }
                    $buyRequest     = new DataObject($requestParams);
                    $result         = $wishlist->addNewItem($product, $buyRequest);
                    $productsName[] = '"' . $product->getName() . '"';
                    if (is_string($result)) {
                        throw new LocalizedException(__($result));
                    }
                }
                $wishlist->save();
                $referer = $this->_customerSession->getBeforeWishlistUrl();
                if ($referer) {
                    $this->_customerSession->setBeforeWishlistUrl(null);
                } else {
                    $referer = $this->_redirect->getRefererUrl();
                }

                $this->wishlistDataHelper->calculate();

                $this->messageManager->addComplexSuccessMessage(
                    'addProductSuccessMessage',
                    [
                        'product_name' => join(', ', $productsName),
                        'referer'      => $referer
                    ]
                );
            }
        } catch (LocalizedException $e) {
            $this->messageManager->addErrorMessage(
                __('We can\'t add the item to Wish List right now: %1.', $e->getMessage())
            );
        } catch (\Exception $e) {
            $this->messageManager->addExceptionMessage(
                $e,
                __('We can\'t add the item to Wish List right now.')
            );
        }
        $resultRedirect->setPath('wishlist/index/index', ['wishlist_id' => $wishlist->getId()]);

        return $resultRedirect;
    }
}
