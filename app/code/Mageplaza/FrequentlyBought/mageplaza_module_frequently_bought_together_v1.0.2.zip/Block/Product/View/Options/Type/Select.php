<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_FrequentlyBought
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\FrequentlyBought\Block\Product\View\Options\Type;

use Magento\Catalog\Model\Product\Option;

/**
 * Class Select
 * @package Mageplaza\FrequentlyBought\Block\Product\View\Options\Type
 */
class Select extends \Magento\Catalog\Block\Product\View\Options\Type\Select
{
    /**
     * Return html for control element
     *
     * @return string
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function getValuesHtml()
    {
        $valueHtml = parent::getValuesHtml();

        $productId = $this->getProduct()->getId();
        $_option   = $this->getOption();
        if ($_option->getType() == Option::OPTION_TYPE_DROP_DOWN || $_option->getType() == Option::OPTION_TYPE_MULTIPLE) {
            $replaceArray = [
                'select_' . $_option->getId()        => 'select_' . $productId . '-' . $_option->getId(),
                'options[' . $_option->getid() . ']' => 'options_' . $productId . '[' . $_option->getid() . ']'
            ];

            $valueHtml = str_replace(array_keys($replaceArray), array_values($replaceArray), $valueHtml);
        }

        if ($_option->getType() == Option::OPTION_TYPE_RADIO || $_option->getType() == Option::OPTION_TYPE_CHECKBOX) {
            $replaceArray = [
                'class="options-list nested"'                              => 'class="mg-fbt-options-list options-list nested"',
                'options-' . $_option->getId() . '-list'                   => 'options-' . $productId . '-' . $_option->getId() . '-list',
                'options_' . $_option->getId()                             => 'options_' . $productId . '_' . $_option->getId(),
                'data-selector="options[' . $_option->getId() . ']" price' => 'data-selector="options' . $productId . '[' . $_option->getId() . ']" price'
            ];

            switch ($_option->getType()) {
                case Option::OPTION_TYPE_RADIO:
                    $replaceArray = array_merge($replaceArray, [
                        'name="options[' . $_option->getId() . ']"'          => 'name="options_' . $productId . '[' . $_option->getId() . ']"',
                        'data-selector="options[' . $_option->getId() . ']"' => 'data-selector="options[' . $productId . '][' . $_option->getId() . ']"'
                    ]);
                    break;
                case Option::OPTION_TYPE_CHECKBOX:
                    $replaceArray = array_merge($replaceArray, [
                        'checkbox admin__control-checkbox' => 'checkbox admin__control-checkbox mp-fbt-multi-select'
                    ]);
                    break;
            }

            $valueHtml = str_replace(array_keys($replaceArray), array_values($replaceArray), $valueHtml);
        }

        return $valueHtml;
    }
}
