<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_FrequentlyBought
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\FrequentlyBought\Block\Product\ProductList;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Block\Product\Context;
use Magento\Catalog\Block\Product\ProductList\Related;
use Magento\Catalog\Model\Product\Visibility;
use Magento\Catalog\Model\ResourceModel\Product\Collection;
use Magento\Checkout\Model\ResourceModel\Cart;
use Magento\Checkout\Model\Session;
use Magento\Framework\Locale\FormatInterface;
use Magento\Framework\Module\Manager;
use Magento\Framework\Pricing\Helper\Data;
use Mageplaza\FrequentlyBought\Helper\Data as FbtData;

/**
 * Class FrequentlyBought
 * @package Mageplaza\FrequentlyBought\Block\Product\ProductList
 */
class FrequentlyBought extends Related
{
    /**
     * @var \Magento\Framework\Pricing\Helper\Data
     */
    protected $priceHelper;

    /**
     * @var \Mageplaza\FrequentlyBought\Helper\Data
     */
    protected $fbtDataHelper;

    /**
     * @var \Magento\Catalog\Api\ProductRepositoryInterface
     */
    protected $productRepository;

    /**
     * @var \Magento\Framework\Locale\FormatInterface
     */
    protected $_localeFormat;

    /**
     * FrequentlyBought constructor.
     * @param \Magento\Catalog\Block\Product\Context $context
     * @param \Magento\Checkout\Model\ResourceModel\Cart $checkoutCart
     * @param \Magento\Catalog\Model\Product\Visibility $catalogProductVisibility
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Framework\Module\Manager $moduleManager
     * @param \Magento\Framework\Pricing\Helper\Data $priceHelper
     * @param \Magento\Catalog\Api\ProductRepositoryInterface $productRepository
     * @param \Mageplaza\FrequentlyBought\Helper\Data $fbtDataHelper
     * @param \Magento\Framework\Locale\FormatInterface $localeFormat
     * @param array $data
     */
    public function __construct(
        Context $context,
        Cart $checkoutCart,
        Visibility $catalogProductVisibility,
        Session $checkoutSession,
        Manager $moduleManager,
        Data $priceHelper,
        ProductRepositoryInterface $productRepository,
        FbtData $fbtDataHelper,
        FormatInterface $localeFormat,
        array $data = [])
    {
        $this->priceHelper       = $priceHelper;
        $this->productRepository = $productRepository;
        $this->fbtDataHelper     = $fbtDataHelper;
        $this->_localeFormat     = $localeFormat;

        parent::__construct($context, $checkoutCart, $catalogProductVisibility, $checkoutSession, $moduleManager, $data);
    }

    /**
     * @inheritdoc
     */
    protected function _addProductAttributesAndPrices(Collection $collection)
    {
        $collection = parent::_addProductAttributesAndPrices($collection);

        $itemLimit = (int)$this->fbtDataHelper->getConfigGeneral('item_limit');
        if ($itemLimit) {
            $collection->getSelect()
                ->limit($itemLimit);
        }

        return $collection;
    }

    /**
     * @return mixed
     */
    public function getJsonConfig()
    {
        $config = [
            'priceFormat' => $this->_localeFormat->getPriceFormat()
        ];

        return FbtData::jsonEncode($config);
    }

    /**
     * Get heading label
     *
     * @return string
     */
    public function getTitleBlock()
    {
        return $this->fbtDataHelper->getConfigGeneral('block_name');
    }

    /**
     * Get price with currency
     *
     * @param   float $price
     * @return string
     */
    public function getPriceWithCurrency($price)
    {
        return $this->priceHelper->currency($price, true, false);
    }

    /**
     * Get price without currency
     *
     * @param   object $product
     * @return float
     */
    public function getPriceAmount($product)
    {
        if ($product->getTypeId() == 'grouped' || $product->getTypeId() == 'bundle') {
            return 0;
        }

        return $product->getPriceInfo()->getPrice('final_price')->getAmount()->getValue();
    }

    /**
     * Get product
     *
     * @return \Magento\Catalog\Model\Product
     */
    public function getCurrentProduct()
    {
        return $this->_coreRegistry->registry('current_product');
    }

    /**
     * Get all custom option product
     *
     * @param null $productId
     * @return mixed
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getCustomOption($productId = null)
    {
        $product = $this->getProductById($productId);
        $option  = $this->getLayout()->getBlock('mageplaza.frequently.bought.product.info.options')
            ->setProduct($product)
            ->toHtml();

        return $option;
    }

    /**
     * Get option product
     *
     * @param null $productId
     * @return bool|\Magento\Framework\View\Element\BlockInterface|string
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getOptionWrapper($productId = null)
    {
        $html        = '';
        $product     = $this->getProductById($productId);
        $productType = $product->getTypeId();
        switch ($productType) {
            case 'configurable' :
                $html = $this->getLayout()->createBlock('Mageplaza\FrequentlyBought\Block\Product\View\Type\Configurable');
                break;
            case 'grouped':
                $html = $this->getLayout()->createBlock('\Magento\GroupedProduct\Block\Product\View\Type\Grouped')
                    ->setTemplate('Mageplaza_FrequentlyBought::product/view/type/grouped.phtml');
                break;
            case 'bundle':
                $html = $this->getLayout()->getBlock('mageplaza.fbt.product.info.bundle.options');
                break;
            case 'downloadable':
                $html = $this->getLayout()->createBlock('\Magento\Downloadable\Block\Catalog\Product\Links')
                    ->setTemplate('Mageplaza_FrequentlyBought::product/view/type/downloadable/links.phtml');
                break;
        }
        if ($html) {
            return $html->setProduct($product)->toHtml();
        }

        return $html;
    }

    /**
     * Get product by id
     *
     * @param null $productId
     * @return \Magento\Catalog\Api\Data\ProductInterface|\Magento\Catalog\Model\Product
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    protected function getProductById($productId = null)
    {
        $storeId = $this->_storeManager->getStore()->getId();
        if ($productId) {
            $product = $this->productRepository->getById($productId, false, $storeId);
        } else {
            $product = $this->getCurrentProduct();
        }

        return $product;
    }

    /**
     * Get separator image config
     *
     * @return string
     */
    public function getSeparatorImage()
    {
        return $this->fbtDataHelper->getIcon();
    }

    /**
     * Get add to wishlist config
     *
     * @return mixed
     */
    public function getShowWishList()
    {
        return $this->fbtDataHelper->getConfigGeneral('enable_add_to_wishlist');
    }
}
